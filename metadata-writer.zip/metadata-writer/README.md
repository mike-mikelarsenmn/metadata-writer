# Metadata Writer

This is a small ticket sidebar app which isn't visible to the UI. The purpose of it is to grab the metadata from the first comment and append it to the ticket comment. 

## To Use:

1. Clone the repository
2. Zip the directory 
3. Upload into your account as a private app.


##  App Tray must be open for the application to function 